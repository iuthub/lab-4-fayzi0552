# Lab 4: Create your Music List

You need to use given repo to create your music list.

### Student Details

- **Student ID**: your studentID
- **Student Name**: your name
- **Section Number**: your course section number